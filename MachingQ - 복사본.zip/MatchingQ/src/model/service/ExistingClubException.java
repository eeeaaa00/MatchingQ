package model.service;

public class ExistingClubException extends Exception {
	private static final long serialVersionUID = 1L;

	public ExistingClubException() {
		super();
	}

	public ExistingClubException(String arg0) {
		super(arg0);
	}
}
