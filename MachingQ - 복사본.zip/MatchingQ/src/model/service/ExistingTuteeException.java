package model.service;

public class ExistingTuteeException extends Exception {

	private static final long serialVersionUID = 1L;

	public ExistingTuteeException() {
		super();
	}

	public ExistingTuteeException(String arg0) {
		super(arg0);
	}
}
