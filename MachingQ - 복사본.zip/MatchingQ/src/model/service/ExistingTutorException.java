package model.service;

public class ExistingTutorException extends Exception {

	private static final long serialVersionUID = 1L;

	public ExistingTutorException() {
		super();
	}

	public ExistingTutorException(String arg0) {
		super(arg0);
	}
}
