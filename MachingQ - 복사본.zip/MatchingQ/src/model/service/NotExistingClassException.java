package model.service;

/**
 * TODO
 */
public class NotExistingClassException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NotExistingClassException() {
		super();
	}

	public NotExistingClassException(String arg0) {
		super(arg0);
	}
}
