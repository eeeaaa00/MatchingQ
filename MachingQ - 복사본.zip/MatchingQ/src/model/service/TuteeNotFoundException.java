package model.service;

public class TuteeNotFoundException extends Exception {

	private static final long serialVersionUID = 1L;

	public TuteeNotFoundException() {
		super();
	}

	public TuteeNotFoundException(String arg0) {
		super(arg0);
	}
}
